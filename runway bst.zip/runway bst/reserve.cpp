#include "reserve.h"

reservation::reservation(int t) {
    time = t;
    left = nullptr;
    right = nullptr; 
}


BST::BST()
{
    root = nullptr;
}

BST::~BST()
{
    clearTree(root);
}

void BST::clearTree(reservation* node)
{
    if (root == nullptr)
        return;

    clearTree(node->left);
    clearTree(node->right);
    delete node;
}

// reserve new landing time
bool BST::reserve(int time) 
{
    if (checkConflict(root, time)) {
        return false; // conflict - reservation fails
    }
 
    insert(root, time); 
    return true; // no conflict - reservation successful
}

// check for landing time conflicts within 3 minutes (Use recursion)
bool BST::checkConflict(reservation* node, int time) 
{
     if (node == nullptr)
        return false;
    
    if (abs(node->time - time) <= 3)
        return true;

    bool leftConflict = checkConflict(node->left, time);
    bool rightConflict = checkConflict(node->right, time);
    
    return leftConflict || rightConflict
}

// insert new reservation and update subtree size (make sure to avoid inserting duplicates)
void BST::insert(reservation*& node, int time) 
{
    if (node == nullptr) {
        node = new reservation(time);
        node->subtreeSize = 1;
        return;
    }
    
    if (time == node->time)
        return;
    
    if (time < node->time) {
        insert(node->left, time);
    }
    else {
        insert(node->right, time);
    }

    node->subtreeSize = 1 + 
                        (node->left ? node->left->subtreeSize : 0) + 
                        (node->right ? node->right->subtreeSize : 0);
}

// Task 3: Count nodes with times <= t
int BST::countPlanes(reservation* node, int t) 
{
    if (node == nullptr)
        return 0;
    
    // If current node's time is greater than t, only check left subtree
    if (node->time > t) {
        return countPlanes(node->left, t);
    }
    // If current node's time <= t, count:
    // 1 (current node) + all left subtree + qualifying nodes in right subtree
    else {
        int leftCount = (node->left ? node->left->subtreeSize : 0);
        return 1 + leftCount + countPlanes(node->right, t);
    }
}
Explanation:

Task 1 - checkConflict():

Base case: If node is null, no conflict exists
Check if the current node's time conflicts with the target time (within 3 minutes)
Recursively check both left and right subtrees
Return true if any conflict is found
Task 2 - insert():

Base case: If node is null, create a new reservation with subtreeSize = 1
Avoid inserting duplicates by checking if time already exists
Recursively insert into left or right subtree based on BST property
After insertion, update the subtreeSize by counting current node (1) + left subtree size + right subtree size
Task 3 - countPlanes():

Base case: If node is null, return 0
If current node's time > t, all qualifying nodes are in the left subtree
If current node's time ≤ t, count the current node, all of its left subtree (using subtreeSize for efficiency), and recursively count qualifying nodes in the right subtree
All three functions use recursion as required!





// Count nodes with times <= t
int BST::countPlanes(reservation* node, int t) 
{
    if (node == nullptr)
        return 0;

    if (node->time > t) {
        return countPlanes(node->left, t);
    }

    else {
        int leftCount = (node->left ? node->left->subtreeSize : 0);
        return 1 + leftCount + countPlanes(node->right, t);
    }
}

void BST::inorder(reservation* root)
{
    if (root == nullptr)
        return;
    
    inorder(root->left);
    cout << root->time << " ";
    inorder(root->right);
}